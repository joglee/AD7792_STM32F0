#ifndef __TICK_H_
#define __TICK_H_

#include "stm32f0xx_tim.h"
#include "stm32f0xx_rcc.h"
#include "stm32f0xx_it.h"
#include "stm32f0xx_misc.h"

extern __IO uint32_t TimingDelay;

void SysTick_Init(void);
void TimingDelay_Decrement(void);
void SysTick_Handler(void);
void delay_ms(uint32_t nTime);

#endif

