#ifndef __AD779X_H
#define __AD779X_H

#include "stm32f0xx.h"
#include "string.h"
#include <stdio.h>

void Delay(unsigned int Time);
void AD7792IOInit(void);
void AD7992Reset(void);
void WriteToReg(unsigned char ByteData);
void ReadFromReg(unsigned char nByte);

#endif

