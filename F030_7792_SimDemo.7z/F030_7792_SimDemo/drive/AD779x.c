#include "AD779x.h"
#include "main.h"
#include <stdio.h>
#include "stdint.h"

extern unsigned char DataRead[3];
void WriteToReg(unsigned char ByteData);
void ReadFromReg(unsigned char nByte);

void Delay(unsigned int Time)
{
	while(Time)
	{
		Time--;
	}
}

void AD7792Reset(void)
{
 	int ResetTime;
	ResetTime=32;
	SCLOCK=1;

 	CS = 0;		  //to keep DIN=1 for 32 sclock to reset the part
 	DIN = 1;
 	while(ResetTime--)
	{
		Delay(10);      
		SCLOCK = 0;
		Delay(10);
 		SCLOCK = 1;
	}
	Delay(10);

	CS = 1;
}

void AD7792IOInit(void)
{
	RCC_AHBPeriphClockCmd( RCC_AHBPeriph_GPIOC|RCC_AHBPeriph_GPIOA, ENABLE);
	
  GPIO_InitTypeDef GPIO_InitStructure; 
  GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_8|GPIO_Pin_11|GPIO_Pin_12; 
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT; 
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  
  GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_8; 
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN; 
  GPIO_Init(GPIOC, &GPIO_InitStructure); 
	
        
  AD7792Reset();
}

void WriteToReg(unsigned char ByteData) // write ByteData to the register
{
	unsigned char temp;
	int i;	
	CS=0;
	temp=0x80;
	for(i=0;i<8;i++)
	{
 		if((temp & ByteData)==0)
		{		
      		DIN=0;
		}	
 		else
		{
			 DIN=1;
     	}
		SCLOCK=0;
		Delay(10);
	   	SCLOCK=1;
		Delay(10);
 		temp=temp>>1;
	}
	CS=1;
}


void ReadFromReg(unsigned char nByte) // nByte is the number of bytes which need to be read
{
	int i,j;
   	unsigned char temp;
   	DIN=1;
 	CS=0;
    temp=0;
	DOUT=1;

	for(i=0; i<nByte; i++)
	{
		for(j=0; j<8; j++)
	    {
	     	SCLOCK=0;
	     	if(DOUT==0)
	     	{
				temp=temp<<1;
		 	}else
		 	{
				temp=temp<<1;
		 		temp=temp+0x01;
			}
			Delay(10);
	        SCLOCK=1;
			Delay(10);
		  }
		  DataRead[i]=temp;
		  temp=0;
	}
    CS=1;
}
