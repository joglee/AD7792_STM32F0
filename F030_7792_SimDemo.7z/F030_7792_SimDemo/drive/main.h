#include "stm32f0xx.h"


struct bit_band
{
	uint16_t bit0:1;
  uint16_t bit1:1;
  uint16_t bit2:1;
  uint16_t bit3:1;
	uint16_t bit4:1;
	uint16_t bit5:1;
	uint16_t bit6:1;
	uint16_t bit7:1;
	uint16_t bit8:1;
	uint16_t bit9:1;
	uint16_t bit10:1;
	uint16_t bit11:1;
	uint16_t bit12:1;
	uint16_t bit13:1;
	uint16_t bit14:1;
	uint16_t bit15:1;

};


#define IOC_I ((struct bit_band *)(&(GPIOC -> IDR)))  //����PC8
#define IOA_O ((struct bit_band *)(&(GPIOA -> ODR)))  //����PC8
#define IOB_I ((struct bit_band *)(&(GPIOB -> IDR)))  //����PC8
#define IOB_O ((struct bit_band *)(&(GPIOB -> ODR)))  //���PB13��14��15

#define CS    		(IOA_O -> bit8)
#define SCLOCK    (IOA_O -> bit12)
#define DIN    		(IOA_O -> bit11)
#define DOUT    	(IOC_I -> bit8)

//#define DOUT    	(IOA_O -> bit11)
//#define DIN    		(IOC_I -> bit8)


void WriteToReg(unsigned char ByteData);
void ReadFromReg(unsigned char nByte);
void Delay(unsigned int Time);
